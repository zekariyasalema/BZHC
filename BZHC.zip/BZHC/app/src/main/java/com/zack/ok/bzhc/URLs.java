package com.zack.ok.bzhc;

public class URLs {
    private static final String ROOT_URL = "http://10.0.3.2:80/BZHC/Android/registrationapi.php?apicall=";
    public static final String URL_REGISTER = ROOT_URL + "signup";
    public static final String URL_LOGIN = ROOT_URL + "login";

}

